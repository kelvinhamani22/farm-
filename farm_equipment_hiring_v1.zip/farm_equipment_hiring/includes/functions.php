<?php
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect_by_role(string $role): void {
    if ($role === 'provider') header('Location: provider/dashboard.php');
    elseif ($role === 'hirer') header('Location: hirer/dashboard.php');
    elseif ($role === 'admin') header('Location: admin/dashboard.php');
    else header('Location: index.php');
    exit;
}
?>
