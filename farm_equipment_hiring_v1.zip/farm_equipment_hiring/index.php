<?php
require 'includes/functions.php';
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FarmHire</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><nav><strong>FarmHire</strong><span><a href="login.php">Login</a> <a href="register.php">Register</a></span></nav>
<section class="hero"><h1>Farm Equipment Hiring Made Easy</h1><p>Find tractors, harvesters, ploughs and other farm equipment from local Providers.</p><a class="button" href="register.php">Get Started</a></section>
<section class="cards"><div><h3>For Hirers</h3><p>Search equipment, check dates, book and pay.</p></div><div><h3>For Providers</h3><p>List equipment, manage availability and earn.</p></div><div><h3>Secure Booking</h3><p>Unavailable dates are automatically protected from double booking.</p></div></section>
</body></html>
