FARM EQUIPMENT HIRING SYSTEM - VERSION 1

1. Install XAMPP with Apache, PHP and MySQL.
2. Copy this folder to C:\xampp\htdocs\farm-equipment
3. Start Apache and MySQL.
4. Open phpMyAdmin.
5. Import database/farm_equipment.sql
6. Open http://localhost/farm-equipment/
7. Register as Provider or Hirer.

ADMIN:
Create an admin by running this SQL after registering a normal account:
UPDATE users SET role='admin' WHERE email='YOUR_ADMIN_EMAIL';

PAYMENTS:
The payment page currently creates a pending payment record for Mobile Money or Card.
A real gateway must be connected before production use. Do not store card numbers/CVV.

BOOKING SAFETY:
The booking flow checks Provider-blocked dates and overlapping active bookings.
The final booking insert is protected by a transaction and equipment row lock.
For production, add stronger database-level reservation locking/idempotency around the payment confirmation webhook.
