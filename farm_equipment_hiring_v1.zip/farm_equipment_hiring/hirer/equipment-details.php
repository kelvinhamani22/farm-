<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('hirer');
$id=(int)($_GET['id'] ?? 0);
$stmt=$pdo->prepare("SELECT e.*,c.name category,u.name provider_name FROM equipment e JOIN equipment_categories c ON c.id=e.category_id JOIN users u ON u.id=e.provider_id WHERE e.id=? AND e.status='active'"); $stmt->execute([$id]); $equi=$stmt->fetch(); if(!$equi) exit('Equipment not found.');
$error=''; $available=null; $total=0;
if($_SERVER['REQUEST_METHOD']==='POST'){
    $start=$_POST['start_date']; $end=$_POST['end_date'];
    if($end < $start){$error='End date must be on or after start date.';}
    else{
        $stmt=$pdo->prepare("SELECT COUNT(*) FROM equipment_unavailable_dates WHERE equipment_id=? AND start_date <= ? AND end_date >= ?");
        $stmt->execute([$id,$end,$start]); $blocked=(int)$stmt->fetchColumn();
        $stmt=$pdo->prepare("SELECT COUNT(*) FROM bookings WHERE equipment_id=? AND status IN ('pending','confirmed','in_progress') AND start_date < ? AND end_date > ?");
        $stmt->execute([$id,$end,$start]); $conflict=(int)$stmt->fetchColumn();
        $available=($blocked===0 && $conflict===0);
        $days=(new DateTime($start))->diff(new DateTime($end))->days + 1;
        $total=$days*(float)$equi['price_day'];
        if($available){ header("Location: booking.php?equipment_id=$id&start_date=".urlencode($start)."&end_date=".urlencode($end)); exit; }
        $error='Equipment is unavailable for the selected dates.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title><?=e($equi['name'])?></title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1><?=e($equi['name'])?></h1><p><?=e($equi['description'])?></p><p><b>Category:</b> <?=e($equi['category'])?></p><p><b>Provider:</b> <?=e($equi['provider_name'])?></p><p><b>Location:</b> <?=e($equi['location'])?></p><p><b>Price:</b> K<?=number_format((float)$equi['price_day'],2)?>/day</p>
<?php if($error):?><div class="alert"><?=e($error)?></div><?php endif;?>
<form method="post"><label>Start date</label><input type="date" name="start_date" min="<?=date('Y-m-d')?>" required><label>End date</label><input type="date" name="end_date" min="<?=date('Y-m-d')?>" required><button>Check Availability & Book</button></form></div></body></html>
