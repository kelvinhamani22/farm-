<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('hirer');
$equipment_id=(int)($_GET['equipment_id'] ?? 0); $start=$_GET['start_date'] ?? ''; $end=$_GET['end_date'] ?? '';
$stmt=$pdo->prepare("SELECT * FROM equipment WHERE id=? AND status='active'"); $stmt->execute([$equipment_id]); $equipment=$stmt->fetch(); if(!$equipment) exit('Equipment not found.');
$days=(new DateTime($start))->diff(new DateTime($end))->days+1; $total=$days*(float)$equipment['price_day']; $deposit=(float)$equipment['security_deposit'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $pdo->beginTransaction();
    try {
        $stmt=$pdo->prepare("SELECT id FROM equipment WHERE id=? AND status='active' FOR UPDATE"); $stmt->execute([$equipment_id]); if(!$stmt->fetch()) throw new Exception('Equipment unavailable.');
        $stmt=$pdo->prepare("SELECT COUNT(*) FROM equipment_unavailable_dates WHERE equipment_id=? AND start_date <= ? AND end_date >= ?");
        $stmt->execute([$equipment_id,$end,$start]); if($stmt->fetchColumn()>0) throw new Exception('Provider has blocked these dates.');
        $stmt=$pdo->prepare("SELECT COUNT(*) FROM bookings WHERE equipment_id=? AND status IN ('pending','confirmed','in_progress') AND start_date < ? AND end_date > ?");
        $stmt->execute([$equipment_id,$end,$start]); if($stmt->fetchColumn()>0) throw new Exception('These dates have just been booked by another Hirer.');
        $ref='FH-'.date('YmdHis').'-'.random_int(100,999);
        $stmt=$pdo->prepare("INSERT INTO bookings(booking_ref,equipment_id,hirer_id,provider_id,start_date,end_date,total_amount,deposit_amount) VALUES(?,?,?,?,?,?,?,?)");
        $stmt->execute([$ref,$equipment_id,$_SESSION['user_id'],$equipment['provider_id'],$start,$end,$total,$deposit]);
        $pdo->commit(); header('Location: payment.php?booking_id='.$pdo->lastInsertId()); exit;
    } catch(Throwable $ex){$pdo->rollBack(); $error=$ex->getMessage();}
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Confirm Booking</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1>Confirm Booking</h1><p><?=e($equipment['name'])?></p><p><?=$start?> to <?=$end?> (<?=$days?> days)</p><h2>K<?=number_format($total,2)?></h2><?php if(!empty($error)):?><div class="alert"><?=e($error)?></div><?php endif;?><form method="post"><button>Continue to Payment</button></form></div></body></html>
