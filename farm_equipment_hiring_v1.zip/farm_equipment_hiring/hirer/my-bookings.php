<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('hirer');
$stmt=$pdo->prepare("SELECT b.*,e.name FROM bookings b JOIN equipment e ON e.id=b.equipment_id WHERE b.hirer_id=? ORDER BY b.created_at DESC"); $stmt->execute([$_SESSION['user_id']]); $rows=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>My Bookings</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1>My Bookings</h1><table><tr><th>Reference</th><th>Equipment</th><th>Dates</th><th>Amount</th><th>Status</th><th>Payment</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['booking_ref'])?></td><td><?=e($r['name'])?></td><td><?=$r['start_date']?> → <?=$r['end_date']?></td><td>K<?=number_format((float)$r['total_amount'],2)?></td><td><?=e($r['status'])?></td><td><?=e($r['payment_status'])?></td></tr><?php endforeach;?></table></div></body></html>
