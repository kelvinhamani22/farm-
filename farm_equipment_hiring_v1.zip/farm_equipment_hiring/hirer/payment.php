<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('hirer');
$id=(int)($_GET['booking_id'] ?? 0);
$stmt=$pdo->prepare("SELECT b.*,e.name FROM bookings b JOIN equipment e ON e.id=b.equipment_id WHERE b.id=? AND b.hirer_id=?"); $stmt->execute([$id,$_SESSION['user_id']]); $booking=$stmt->fetch(); if(!$booking) exit('Booking not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $method=$_POST['method'];
    if(!in_array($method,['mobile_money','card'],true)) exit('Invalid payment method.');
    $stmt=$pdo->prepare("INSERT INTO payments(booking_id,method,amount,status) VALUES(?,?,?,'pending')");
    $stmt->execute([$id,$method,$booking['total_amount']]);
    header('Location: my-bookings.php?payment_pending=1'); exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Payment</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1>Payment</h1><p><?=e($booking['name'])?></p><h2>K<?=number_format((float)$booking['total_amount'],2)?></h2><p>Choose a payment method. The gateway connection can be configured next.</p><form method="post"><select name="method"><option value="mobile_money">Mobile Money</option><option value="card">Card</option></select><button>Proceed Securely</button></form></div></body></html>
