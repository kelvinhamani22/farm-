<?php
require 'config/database.php';
require 'includes/functions.php';
if (session_status() === PHP_SESSION_NONE) session_start();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'hirer';
    $location = trim($_POST['location'] ?? '');

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
        $error = 'Enter valid details. Password must be at least 6 characters.';
    } elseif (!in_array($role, ['provider','hirer'], true)) {
        $error = 'Invalid account type.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO users (name,email,phone,password,role,location) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$name,$email,$phone,password_hash($password,PASSWORD_DEFAULT),$role,$location]);
            header('Location: login.php?registered=1');
            exit;
        } catch (PDOException $e) {
            $error = $e->getCode() === '23000' ? 'Email is already registered.' : 'Registration failed.';
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Register</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><div class="auth-card"><h1>FarmHire</h1><h2>Create Account</h2>
<?php if ($error): ?><div class="alert"><?=e($error)?></div><?php endif; ?>
<form method="post">
<input name="name" placeholder="Full name" required>
<input type="email" name="email" placeholder="Email" required>
<input name="phone" placeholder="Phone number" required>
<input name="location" placeholder="Location">
<select name="role"><option value="hirer">Hirer</option><option value="provider">Provider</option></select>
<input type="password" name="password" placeholder="Password (minimum 6)" required>
<button>Register</button>
</form><p>Already registered? <a href="login.php">Login</a></p></div></body></html>
