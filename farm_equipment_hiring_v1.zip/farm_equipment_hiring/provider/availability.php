<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('provider');
$id=(int)($_GET['id'] ?? $_POST['equipment_id'] ?? 0);
$stmt=$pdo->prepare("SELECT * FROM equipment WHERE id=? AND provider_id=?"); $stmt->execute([$id,$_SESSION['user_id']]); $equipment=$stmt->fetch(); if(!$equipment) exit('Equipment not found.');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $stmt=$pdo->prepare("INSERT INTO equipment_unavailable_dates(equipment_id,start_date,end_date,reason) VALUES(?,?,?,?)");
    $stmt->execute([$id,$_POST['start_date'],$_POST['end_date'],trim($_POST['reason'])]);
}
$stmt=$pdo->prepare("SELECT * FROM equipment_unavailable_dates WHERE equipment_id=? ORDER BY start_date"); $stmt->execute([$id]); $dates=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Availability</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1>Block Dates: <?=e($equipment['name'])?></h1>
<form method="post"><input type="hidden" name="equipment_id" value="<?=$id?>"><input type="date" name="start_date" required><input type="date" name="end_date" required><input name="reason" placeholder="Reason"><button>Block Dates</button></form>
<table><tr><th>Start</th><th>End</th><th>Reason</th></tr><?php foreach($dates as $d):?><tr><td><?=$d['start_date']?></td><td><?=$d['end_date']?></td><td><?=e($d['reason'])?></td></tr><?php endforeach;?></table></div></body></html>
