<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('provider');
$stmt=$pdo->prepare("SELECT e.*,c.name category FROM equipment e JOIN equipment_categories c ON c.id=e.category_id WHERE e.provider_id=? ORDER BY e.id DESC"); $stmt->execute([$_SESSION['user_id']]); $rows=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>My Equipment</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1>My Equipment</h1><a class="button" href="add-equipment.php">Add Equipment</a><table><tr><th>Name</th><th>Category</th><th>Location</th><th>Daily Price</th><th>Status</th><th>Availability</th></tr>
<?php foreach($rows as $r):?><tr><td><?=e($r['name'])?></td><td><?=e($r['category'])?></td><td><?=e($r['location'])?></td><td>K<?=number_format((float)$r['price_day'],2)?></td><td><?=e($r['status'])?></td><td><a href="availability.php?id=<?=$r['id']?>">Manage dates</a></td></tr><?php endforeach;?></table></div></body></html>
