<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('provider');
$cats=$pdo->query("SELECT * FROM equipment_categories ORDER BY name")->fetchAll(); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $stmt=$pdo->prepare("INSERT INTO equipment (provider_id,category_id,name,description,manufacturer,model,equipment_year,condition_status,location,price_hour,price_day,price_week,security_deposit) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$_SESSION['user_id'],$_POST['category_id'],trim($_POST['name']),trim($_POST['description']),trim($_POST['manufacturer']),trim($_POST['model']),$_POST['equipment_year'] ?: null,$_POST['condition_status'],trim($_POST['location']),$_POST['price_hour'] ?: 0,$_POST['price_day'] ?: 0,$_POST['price_week'] ?: 0,$_POST['security_deposit'] ?: 0]);
    header('Location: my-equipment.php'); exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Add Equipment</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<div class="container"><h1>Add Equipment</h1><form method="post" class="form-grid">
<input name="name" placeholder="Equipment name" required><select name="category_id" required><?php foreach($cats as $c):?><option value="<?=$c['id']?>"><?=e($c['name'])?></option><?php endforeach;?></select>
<input name="manufacturer" placeholder="Manufacturer"><input name="model" placeholder="Model"><input name="equipment_year" type="number" placeholder="Year"><input name="condition_status" value="Good" placeholder="Condition"><input name="location" placeholder="Location" required>
<input name="price_hour" type="number" step="0.01" placeholder="Price/hour"><input name="price_day" type="number" step="0.01" placeholder="Price/day" required><input name="price_week" type="number" step="0.01" placeholder="Price/week"><input name="security_deposit" type="number" step="0.01" placeholder="Security deposit">
<textarea name="description" placeholder="Description"></textarea><button>Add Equipment</button></form></div></body></html>
