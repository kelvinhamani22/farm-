<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('provider');
if(isset($_POST['action'],$_POST['id'])){
    $status=$_POST['action']==='accept'?'confirmed':'rejected';
    $stmt=$pdo->prepare("UPDATE bookings SET status=? WHERE id=? AND provider_id=? AND status='pending'");
    $stmt->execute([$status,(int)$_POST['id'],$_SESSION['user_id']]);
}
$stmt=$pdo->prepare("SELECT b.*,e.name,u.name hirer_name FROM bookings b JOIN equipment e ON e.id=b.equipment_id JOIN users u ON u.id=b.hirer_id WHERE b.provider_id=? ORDER BY b.created_at DESC"); $stmt->execute([$_SESSION['user_id']]); $rows=$stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Bookings</title><link rel="stylesheet" href="../assets/css/style.css"></head><body><div class="container"><h1>Booking Requests</h1><table><tr><th>Ref</th><th>Hirer</th><th>Equipment</th><th>Dates</th><th>Amount</th><th>Status</th><th>Action</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['booking_ref'])?></td><td><?=e($r['hirer_name'])?></td><td><?=e($r['name'])?></td><td><?=$r['start_date']?> → <?=$r['end_date']?></td><td>K<?=number_format((float)$r['total_amount'],2)?></td><td><?=e($r['status'])?></td><td><?php if($r['status']==='pending'):?><form method="post" style="display:inline"><input type="hidden" name="id" value="<?=$r['id']?>"><button name="action" value="accept">Accept</button><button name="action" value="reject">Reject</button></form><?php endif;?></td></tr><?php endforeach;?></table></div></body></html>
