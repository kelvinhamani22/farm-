<?php
require '../config/database.php'; require '../includes/auth.php'; require '../includes/functions.php'; require_role('provider');
$stmt=$pdo->prepare("SELECT COUNT(*) FROM equipment WHERE provider_id=?"); $stmt->execute([$_SESSION['user_id']]); $equipmentCount=$stmt->fetchColumn();
$stmt=$pdo->prepare("SELECT COUNT(*) FROM bookings WHERE provider_id=? AND status IN ('pending','confirmed','in_progress')"); $stmt->execute([$_SESSION['user_id']]); $bookingCount=$stmt->fetchColumn();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Provider Dashboard</title><link rel="stylesheet" href="../assets/css/style.css"></head><body>
<nav><strong>FarmHire Provider</strong><span>Hi, <?=e($_SESSION['name'])?> | <a href="../logout.php">Logout</a></span></nav>
<div class="container"><h1>Provider Dashboard</h1><div class="cards"><div><h2><?=$equipmentCount?></h2><p>Equipment</p></div><div><h2><?=$bookingCount?></h2><p>Active Bookings</p></div></div>
<a class="button" href="add-equipment.php">+ Add Equipment</a> <a class="button" href="my-equipment.php">My Equipment</a> <a class="button" href="bookings.php">Bookings</a></div></body></html>
